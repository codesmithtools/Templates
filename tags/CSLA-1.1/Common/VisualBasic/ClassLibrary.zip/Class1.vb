﻿Public Class $itemname$

End Class
