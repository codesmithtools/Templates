﻿Imports System.Globalization
Imports System.Security.Principal

<HandleError()> _
<OutputCache(Location:=OutputCacheLocation.None)> _
Public Class AccountController
    Inherits System.Web.Mvc.Controller

    Private _formsAuth As IFormsAuthentication
    Private _provider As MembershipProvider

    Sub New()
        Me.New(Nothing, Nothing)
    End Sub

    Sub New(ByVal formsAuth As IFormsAuthentication, ByVal provider As MembershipProvider)
        _formsAuth = If(formsAuth, New FormsAuthenticationWrapper())
        _provider = If(provider, Membership.Provider)
    End Sub

    ReadOnly Property FormsAuth() As IFormsAuthentication
        Get
            Return _formsAuth
        End Get
    End Property

    ReadOnly Property Provider() As MembershipProvider
        Get
            Return _provider
        End Get
    End Property

    <Authorize()> _
    Function ChangePassword(ByVal currentPassword As String, ByVal newPassword As String, ByVal confirmPassword As String)

        ViewData("Title") = "Change Password"
        ViewData("PasswordLength") = Provider.MinRequiredPasswordLength

        ' Non-POST requests should just display the ChangePassword form
        If Request.HttpMethod <> "POST" Then
            Return View()
        End If

        ' Basic parameter validation
        Dim errors As New List(Of String)

        If String.IsNullOrEmpty(currentPassword) Then
            errors.Add("You must specify a current password.")
        End If
        If newPassword Is Nothing OrElse newPassword.Length < Provider.MinRequiredPasswordLength Then
            errors.Add(String.Format(CultureInfo.InvariantCulture, _
                                     "You must specify a new password of {0} or more characters.", _
                                     Provider.MinRequiredPasswordLength))
        End If
        If Not String.Equals(newPassword, confirmPassword, StringComparison.Ordinal) Then
            errors.Add("The new password and confirmation password do not match.")
        End If

        If errors.Count = 0 Then

            ' Attempt to change password
            Dim currentUser As MembershipUser = Provider.GetUser(User.Identity.Name, True)
            Dim changeSuccessful As Boolean = False
            Try
                changeSuccessful = currentUser.ChangePassword(currentPassword, newPassword)
            Catch
                ' An exception is thrown if the new password does not meet the provider's requirements
            End Try

            If changeSuccessful Then
                Return RedirectToAction("ChangePasswordSuccess")
            Else
                errors.Add("The current password is incorrect or the new password is invalid.")
            End If
        End If

        ' If we got this far, something failed, redisplay form
        ViewData("errors") = errors
        Return View()
    End Function

    Function ChangePasswordSuccess()

        ViewData("Title") = "Change Password"

        Return View()
    End Function

    Function Login(ByVal username As String, ByVal password As String, ByVal rememberMe As Boolean?)

        ViewData("Title") = "Login"

        ' Non-POST requests should just display the Login form
        If Request.HttpMethod <> "POST" Then
            Return View()
        End If

        ' Basic parameter validation
        Dim errors As New List(Of String)
        If String.IsNullOrEmpty(username) Then
            errors.Add("You must specify a username.")
        End If

        If errors.Count = 0 Then

            ' Attempt to login
            Dim loginSuccessful As Boolean = Provider.ValidateUser(username, password)
            If loginSuccessful Then

                FormsAuth.SetAuthCookie(username, If(rememberMe, False))
                Return RedirectToAction("Index", "Home")
            Else
                errors.Add("The username or password provided is incorrect.")
            End If
        End If

        ' If we got this far, something failed, redisplay form
        ViewData("errors") = errors
        ViewData("username") = username
        Return View()
    End Function

    Function Logout()

        FormsAuth.SignOut()
        Return RedirectToAction("Index", "Home")
    End Function

    Protected Overrides Sub OnActionExecuting(ByVal filterContext As System.Web.Mvc.ActionExecutingContext)
        If TypeOf filterContext.HttpContext.User.Identity Is WindowsIdentity Then
            Throw New InvalidOperationException("Windows authentication is not supported.")
        End If
    End Sub

    Function Register(ByVal username As String, ByVal email As String, ByVal password As String, ByVal confirmPassword As String)

        ViewData("Title") = "Register"
        ViewData("PasswordLength") = Provider.MinRequiredPasswordLength

        ' Non-POST requests should just display the Register form
        If Request.HttpMethod <> "POST" Then
            Return View()
        End If

        ' basic parameter validation
        Dim errors As New List(Of String)
        If String.IsNullOrEmpty(username) Then
            errors.Add("You must specify a username.")
        End If
        If String.IsNullOrEmpty(email) Then
            errors.Add("You must specify an email address.")
        End If
        If password Is Nothing OrElse password.Length < Provider.MinRequiredPasswordLength Then
            errors.Add(String.Format(CultureInfo.InvariantCulture, _
                                     "You must specify a password of {0} or more characters.", _
                                     Provider.MinRequiredPasswordLength))
        End If
        If Not String.Equals(password, confirmPassword, StringComparison.Ordinal) Then
            errors.Add("The password and confirmation do not match.")
        End If

        If errors.Count = 0 Then

            ' Attempt to register the user
            Dim createStatus As MembershipCreateStatus
            Dim newUser As MembershipUser = Provider.CreateUser(username, password, email, Nothing, Nothing, True, Nothing, createStatus)
            If newUser IsNot Nothing Then

                FormsAuth.SetAuthCookie(username, False)
                Return RedirectToAction("Index", "Home")
            Else
                errors.Add(ErrorCodeToString(createStatus))
            End If
        End If

        ' If we got this far, something failed, redisplay form
        ViewData("errors") = errors
        ViewData("username") = username
        ViewData("email") = email
        Return View()
    End Function

    Shared Function ErrorCodeToString(ByVal createStatus As MembershipCreateStatus) As String
        ' See http://msdn.microsoft.com/en-us/library/system.web.security.membershipcreatestatus.aspx for
        ' a full list of status codes.
        Select Case createStatus
            Case MembershipCreateStatus.DuplicateUserName
                Return "Username already exists. Please enter a different user name."

            Case MembershipCreateStatus.DuplicateEmail
                Return "A username for that e-mail address already exists. Please enter a different e-mail address."

            Case MembershipCreateStatus.InvalidPassword
                Return "The password provided is invalid. Please enter a valid password value."

            Case MembershipCreateStatus.InvalidEmail
                Return "The e-mail address provided is invalid. Please check the value and try again."

            Case MembershipCreateStatus.InvalidAnswer
                Return "The password retrieval answer provided is invalid. Please check the value and try again."

            Case MembershipCreateStatus.InvalidQuestion
                Return "The password retrieval question provided is invalid. Please check the value and try again."

            Case MembershipCreateStatus.InvalidUserName
                Return "The user name provided is invalid. Please check the value and try again."

            Case MembershipCreateStatus.ProviderError
                Return "The authentication provider returned an error. Please verify your entry and try again. If the problem persists, please contact your system administrator."

            Case MembershipCreateStatus.UserRejected
                Return "The user creation request has been canceled. Please verify your entry and try again. If the problem persists, please contact your system administrator."

            Case Else
                Return "An unknown error occurred. Please verify your entry and try again. If the problem persists, please contact your system administrator."
        End Select

    End Function

End Class

' The FormsAuthentication type is sealed and contains static members, so it is difficult to
' unit test code that calls its members. The interface and helper class below demonstrate
' how to create an abstract wrapper around such a type in order to make the AccountController
' code unit testable.

Public Interface IFormsAuthentication
    Sub SetAuthCookie(ByVal userName As String, ByVal createPersistentCookie As Boolean)
    Sub SignOut()
End Interface

Public Class FormsAuthenticationWrapper
    Implements IFormsAuthentication

    Public Sub SetAuthCookie(ByVal userName As String, ByVal createPersistentCookie As Boolean) Implements IFormsAuthentication.SetAuthCookie
        FormsAuthentication.SetAuthCookie(userName, createPersistentCookie)
    End Sub

    Public Sub SignOut() Implements IFormsAuthentication.SignOut
        FormsAuthentication.SignOut()
    End Sub
End Class
