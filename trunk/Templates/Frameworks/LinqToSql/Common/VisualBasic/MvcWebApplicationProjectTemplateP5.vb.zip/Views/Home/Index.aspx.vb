﻿Public Partial Class Index
    Inherits System.Web.Mvc.ViewPage

End Class
