﻿Public Partial Class Site
    Inherits System.Web.Mvc.ViewMasterPage

End Class
