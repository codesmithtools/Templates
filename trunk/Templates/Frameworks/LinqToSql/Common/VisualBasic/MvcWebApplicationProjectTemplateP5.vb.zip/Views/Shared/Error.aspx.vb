﻿Partial Public Class [Error]
    Inherits System.Web.Mvc.ViewPage(Of HandleErrorInfo)


End Class
