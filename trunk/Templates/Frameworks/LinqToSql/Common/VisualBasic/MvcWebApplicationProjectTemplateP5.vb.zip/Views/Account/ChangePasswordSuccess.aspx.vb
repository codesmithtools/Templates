﻿Public Partial Class ChangePasswordSuccess
    Inherits System.Web.Mvc.ViewPage

End Class
