﻿Public Partial Class Login
    Inherits System.Web.Mvc.ViewPage

End Class
