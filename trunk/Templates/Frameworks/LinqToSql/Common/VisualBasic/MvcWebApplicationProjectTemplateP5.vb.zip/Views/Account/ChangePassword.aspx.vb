﻿Public Partial Class ChangePassword
    Inherits System.Web.Mvc.ViewPage

End Class
