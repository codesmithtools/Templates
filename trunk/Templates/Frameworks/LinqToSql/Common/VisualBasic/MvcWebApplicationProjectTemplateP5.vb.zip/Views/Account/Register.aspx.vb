﻿Public Partial Class Register
    Inherits System.Web.Mvc.ViewPage

End Class
