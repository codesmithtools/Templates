﻿Public Partial Class About
    Inherits System.Web.Mvc.ViewPage

End Class
