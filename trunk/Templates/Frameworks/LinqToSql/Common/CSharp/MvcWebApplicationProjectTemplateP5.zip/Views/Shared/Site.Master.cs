﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace $safeprojectname$.Views.Shared {
    public partial class Site : System.Web.Mvc.ViewMasterPage {
    }
}
