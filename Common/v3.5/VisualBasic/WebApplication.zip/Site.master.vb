﻿Imports System.Web.DynamicData

Partial Class Site
    Inherits System.Web.UI.MasterPage

    

End Class
