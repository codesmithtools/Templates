﻿using System.Web;
using System.Web.Optimization;

namespace $safeprojectname$
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            // Clear all items from the default ignore list to allow minified CSS and JavaScript files to be included in debug mode
            bundles.IgnoreList.Clear();
            
            // Add back the default ignore list rules sans the ones which affect minified files and debug mode
            bundles.IgnoreList.Ignore("*.intellisense.js");
            bundles.IgnoreList.Ignore("*-vsdoc.js");
            bundles.IgnoreList.Ignore("*.debug.js", OptimizationMode.WhenEnabled);

            bundles.Add(new ScriptBundle("~/bundles/kendojs").Include(
                "~/Scripts/jquery-1.8.3.min.js",
                "~/Scripts/kendo/2012.3.1114/kendo.web.min.js"));

            bundles.Add(new StyleBundle("~/Content/kendocss").Include(
                "~/Content/kendo/2012.3.1114/kendo.common.min.css",
                "~/Content/kendo/2012.3.1114/kendo.default.min.css"));

            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include("~/Scripts/modernizr-*"));
            bundles.Add(new StyleBundle("~/Content/css").Include("~/Content/site.css"));
        }
    }
}